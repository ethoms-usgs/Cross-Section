import arcgisscripting, sys
gp = arcgisscripting.create()
gp.workspace = "D:/Workspace/PythonProjects/CrossSectionToolbox/scratch"
infc = "polytest_DissolveCopy.shp"
# Identify the geometry field
desc = gp.Describe(infc)
shapefieldname = desc.ShapeFieldName
saveout = sys.stdout
sys.stdout = open("D:/Workspace/PythonProjects/CrossSectionToolbox/scratch/polylog.txt", "w")

# Create search cursor
rows = gp.SearchCursor(infc)
row = rows.Next()
# Enter while loop for each feature/row
#while row:
# for polygons/lines
    
# Create the geometry object
feat = row.GetValue("shape")
# Print the current multipoint's ID
print "Feature " + str(row.getvalue(desc.OIDFieldName)) + ":"
partnum = 0
# Count the number of points in the current multipart feature
partcount = feat.PartCount
# Enter while loop for each part in the feature (if a singlepart feature
# this will occur only once)
while partnum < partcount:
    # Print the part number
    print "Part " + str(partnum) + ":"
    part = feat.GetPart(partnum)
    pnt = part.Next()
    pntcount = 0
    # Enter while loop for each vertex
    while pnt:
        # Print x, y coordinates of current point
        print pnt.x, pnt.y, pnt.z
        pnt = part.Next()
        pntcount += 1

        # If pnt is null, either the part is finished or there is an 
        # interior ring
        if not pnt: 
            pnt = part.Next()
            if pnt:
                print "Interior Ring:"
    partnum += 1
##    row = rows.Next()

# for points    
##    # Create the geometry object 'feat'
##    feat = row.GetValue(shapefieldname)
##    pnt = feat.GetPart()
##    # Print x, y coordinates of current point
##    print row.getvalue("fid"), pnt.x, pnt.y
    #row = rows.Next()
sys.stdout = saveout
print "saveout"
