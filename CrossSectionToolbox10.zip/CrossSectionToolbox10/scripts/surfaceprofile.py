'''
Name: surfaceprofile.py
Description: ArcToolbox tool script to create one or more surface profiles from an ArcMap line layer
    in a cross-sectional view shapefile. Requires a line layer and a DEM in the same
    coordinate system.
Requirements: 3D Analyst extension, CreateRoutes extension is available with all Arc modules
Author: Evan Thoms, U.S. Geological Survey, ethoms@usgs.gov
Date: 8/8/07
mods beginning 5/21/10

updates to ArcGIS 10 beginning 3/18/11
'''

import sys
import os
import traceback
import arcpy
import xsec_defs  
#xsec_defs.py must be in the folder with this script or nested
#below it, eg, \scripts\bin

# FUNCTIONS
# ***************************************************************
def checkExtensions():
    #Check for the 3d Analyst extension
    try:
        if arcpy.CheckExtension('3D') == 'Available':
            arcpy.CheckOutExtension('3D')
        else:
            raise 'LicenseError'

    except 'LicenseError':
        arcpy.AddMessage('3D Analyst extension is unavailable')
        raise SystemError
    except:
        print arcpy.GetMessages(2)

# PARAMETERS
# ***************************************************************
try:
    arcpy.env.overwriteOutput = True
    
    # Cross section(s) layer
    linesLayer = arcpy.GetParameterAsText(0)

    # elevation raster layer
    dem = arcpy.GetParameterAsText(1)

    #coordinate priority - corner from which the measuring will begin
    cp = xsec_defs.getCPValue(arcpy.GetParameterAsText(2))

    # vertical exaggeration
    ve = arcpy.GetParameterAsText(3)

    # output feature class
    outFC = arcpy.GetParameterAsText(4)
    outName = os.path.splitext(os.path.basename(outFC))[0]

    #append features boolean
    append = arcpy.GetParameterAsText(5)

    #append to feature class...
    appendFC = arcpy.GetParameterAsText(6)

    #plot WRT to another line boolean
    plotWRT = arcpy.GetParameterAsText(7)

    #wrt line feature class
    wrtLineFC = arcpy.GetParameterAsText(8)

    #data frame name
    dfName = arcpy.GetParameterAsText(9)

    # BEGIN
    # ***************************************************************
    #check the availability of the 3d Analyst extension
    checkExtensions()

    arcpy.env.overwriteOutput = True

    #get the scratch directory
    scratchDir = arcpy.env.scratchWorkspace

    #set the current workspace env
    arcpy.env.workspace = scratchDir
    
    #add an rkey field to the table that consists of values from the OID
    desc = arcpy.Describe(linesLayer)
    idField = desc.OIDFieldName
    xsec_defs.addAndCalc(linesLayer, 'ORIG_FID', '[' + idField + ']')
    
    #find out if linesLayer is measured and interpolated
    #(has M and Z values) - if so, we can avoid the interpolate and measure functions
    desc = arcpy.Describe(linesLayer)
    hasM = desc.hasM
    hasZ = desc.hasZ

##    if hasZ and hasM:
##       zmAtts = linesLayer
##    else:
    #interpolate the lines
    zLines = outName + '_z'
    xsec_defs.interpolate(linesLayer, dem, zLines)

    #measure the lines
    zmLines = outName + '_zm'
    xsec_defs.measureLines(zLines, 'ORIG_FID', zmLines, 'LENGTH', '#', '#', cp)
    
    #hook the attributes back up
    #transferAtts(inFC, joinTable, parentKey, childKey, fInfo, outName)
    zmAtts = outName + '_zmAtts'
    xsec_defs.transferAtts(zmLines, linesLayer, 'ORIG_FID', 'ORIG_FID', '#', zmAtts)

    #make an empty container with an 'Unknown' SR
    zmProfiles = outName + '_profiles'
    arcpy.CreateFeatureclass_management(scratchDir, zmProfiles, 'POLYLINE', linesLayer, 'ENABLED', 'ENABLED')
    arcpy.Append_management(zmAtts, zmProfiles, 'NO_TEST')
    xsec_defs.plan2side(zmProfiles, ve)
    
    #check plotWRT boolean
    if plotWRT == 'true':
    
        #create points that represent the intersections between the profile lines
        #and the single intersection line
        intersectFC = outName + '_intersectPts'
        xsec_defs.intersectFeatures([linesLayer, wrtLineFC], intersectFC, '#', '#', 'POINT')

        #now, locate those points on the profile routes
        #a field called 'Distance' will be created that shows the distance
        #from the beginning of the profile line to the point of intersection
        #the offset required to plot the profile wrt to the intersecting line
        intersectTab = outName + '_intersectTab'
        rProps = 'rkey POINT Distance'
        xsec_defs.createEventTable(intersectFC, zmLines, 'ORIG_FID', 1, intersectTab, rProps)

        #now update the profiles
        profiles = arcpy.UpdateCursor(zmProfiles)

        maxY = 0
        minY = 0
        for profile in profiles:
            #get the offset for this profile
            #first, get the route key of this profile
            rte = profile.ORIG_FID
            if not rte == None:
                #and create a search cursor of hopefully just one row where the rkeys
                #in the profiles fc and the intersect table are the same
                where = '"rkey" = ' + str(rte)
                rows = arcpy.SearchCursor(intersectTab, where)
                #get the offset distance
                offset = rows.next().Distance

                #create an empty container for the re-calced profile geometry
                newProf = arcpy.CreateObject('array')

                #get the existing geometry
                feat = profile.shape
                part = feat.getPart(0)

                for pnt in part:
                    #recalc each x coordinate and add it to the new array object
                    pnt.X = pnt.X - offset
                    newProf.add(pnt)
                    
                    #compare Y values for the min and max of the dataset
                    if pnt.Y > maxY: maxY = pnt.Y
                    if pnt.Y < minY: minY = pnt.Y

                #set the old profile shape to the new and update
                profile.shape = newProf
                profiles.updateRow(profile)
        

        #now insert one last vertical line to show the location of intersection
        rows = arcpy.InsertCursor(zmProfiles)
        row = rows.newRow()
            
        #create some empty geometry objects
        lineArray = arcpy.Array()
        pnt1 = arcpy.Point()
        pnt2 = arcpy.Point()
            
        #update the properties of the objects
        pnt1.X = 0
        pnt1.Y = (minY - 500.0)
        lineArray.add(pnt1)
            
        pnt2.X = 0
        pnt2.Y = (maxY + 500.0)
        lineArray.add(pnt2)
            
        #add the new feature
        row.shape = lineArray
        rows.insertRow(row)

    #now, to worry about the output
    #check to see if we are to append the features to an existing fc
    if append == 'true':
        arcpy.AddMessage('Appending features to ' + appendFC)
        arcpy.Append_management(zmProfiles, appendFC)
        outLayer = appendFC

    else:
        #or copy the final fc from the scratch gdb to the output directory/gdb
        srcProfiles = os.path.join(scratchDir, zmProfiles)
        arcpy.CopyFeatures_management(srcProfiles, outFC)
        outLayer = outFC


    #now, check for whether the user wants the output in a particular data frame
    #seems to inconsistently activate the data frame
    #layer will not be added unless Geoprocessing > Geoprocessing Options >
    #   'Add results of geoprocessing operations to the display' is checked
    if not dfName == '':
        mxd = arcpy.mapping.MapDocument('Current')
        df = arcpy.mapping.ListDataFrames(mxd, dfName)[0]
        mxd.activeView = df
        arcpy.SetParameterAsText(10, outLayer)

except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = tbinfo + '\n' + str(sys.exc_type)+ ': ' + str(sys.exc_value)
    arcpy.AddError(pymsg)
    raise SystemError
