'''lineintersect.py
Description: ArcToolbox tool to find the intersections between a line of 
    cross section and all of the lines in a line layer crossing it and plot 
    those locations in cross section view.
Requirements: 3D Analyst extension
Author: Evan Thoms, U.S. Geological Survey, ethoms@usgs.gov
Date: 6/29/10

Upgrades to ArcGIS 10 started 7/13/11
'''

# Import modules
import os
import sys
import traceback
import arcpy
import xsec_defs

# FUNCTIONS
# *******************************************************
def checkExtensions():
    #Check for the 3d Analyst extension
    try:
        if arcpy.CheckExtension('3D') == 'Available':
            arcpy.CheckOutExtension('3D')
        else:
            raise 'LicenseError'

    except 'LicenseError':
        arcpy.AddMessage('3D Analyst extension is unavailable')
        raise SystemError
    except:
        print arcpy.GetMessages(2)

arcpy.env.overwriteOutput = True

# PARAMETERS
# *******************************************************
# Cross section(s) layer
lineLayer = arcpy.GetParameterAsText(0)

#might be a path, so we have to get the name of the file
if os.path.isabs(lineLayer):
    lineLayer = os.path.splitext(os.path.basename(lineLayer))[0]

#can't figure out how to put this in the validator class ??
result = arcpy.GetCount_management(lineLayer)
if int(result.getOutput(0)) > 1:
    arcpy.AddError(lineLayer + ' has more than one line in it.')

# elevation raster layer
dem = arcpy.GetParameterAsText(1)

#coordinate priority - corner from which the measuring will begin
cp = xsec_defs.getCPValue(arcpy.GetParameterAsText(2))

#intersecting lines layer
linesLayer = arcpy.GetParameterAsText(3)

#output features to be points or lines?
outShape = arcpy.GetParameterAsText(4)

# vertical exaggeration
ve = arcpy.GetParameterAsText(5)

# output feature class
outFC = arcpy.GetParameterAsText(6)
outName = os.path.splitext(os.path.basename(outFC))[0]

#append to existing feature class?
append = arcpy.GetParameterAsText(7)

#append target
appendFC = arcpy.GetParameterAsText(8)
if append == 'true':
	outName = os.path.splitext(os.path.basename(appendFC))[0]
	
#data frame name
dfName = arcpy.GetParameterAsText(9)

#BEGIN
#*******************************************************
try:
	#check for 3DAnalyst extension
	checkExtensions()

	#get the scratch directory
	scratchDir = arcpy.env.scratchWorkspace

    #set the current workspace env
	arcpy.env.workspace = scratchDir
	
    #find out if lineLayer is measured and interpolated
    #(has M and Z values) - if so, we can avoid the next two function calls
	desc = arcpy.Describe(lineLayer)
	hasM = desc.hasM
	hasZ = desc.hasZ

	#add an ORIG_FID field to the table that consists of values from the OID
	desc = arcpy.Describe(lineLayer)
	idField = desc.OIDFieldName
	xsec_defs.addAndCalc(lineLayer, 'ORIG_FID', '[' + idField + ']')

    #check for Z and M values. User's responsibility to make sure the
	#units are consistent with other layers, output, etc.
	if hasZ and hasM:
		ZMline = lineLayer
	else:
        #interpolate the line to add z values
		Zline = lineLayer + '_Z'
		xsec_defs.interpolate(lineLayer, dem, Zline)
        
        #measure it and turn it into a route
		ZMline = lineLayer + '_ZM'
		xsec_defs.measureLines(Zline, 'ORIG_FID', ZMline, 'LENGTH', '#', '#', cp)

	#intersect with lines layer
	intersectPts = outName + '_interPts'
	inList = lineLayer + ';' + linesLayer
	xsec_defs.intersectFeatures(inList, intersectPts, 'all', '#', 'point')

	#get elevations for the intersection locations
	ZinterPts = outName + '_ZinterPts'
	xsec_defs.interpolate(intersectPts, dem, ZinterPts)

	# Add DEM Z values to ZinterPts attribute table
	xsec_defs.addZ(ZinterPts)

	# locate intersection points along cross section
	eventTable = outName + '_interEvents'
	rProps = 'rkey POINT RouteM'
	xsec_defs.createEventTable(ZinterPts, ZMline, 'ORIG_FID', '10', eventTable, rProps)
	
	if outShape == 'lines':
		xInterPts = outName + '_xsecLines'
		xsec_defs.boreholeLines(scratchDir, xInterPts, ZinterPts, eventTable, 'OBJECTID', 'DEM_Z', '#', ve)
	else:
		xInterPts = outName + '_xsecPts'
		xsec_defs.xsecPoints(xInterPts, ZinterPts, eventTable, 'DEM_Z', ve, scratchDir)

    #now, to worry about the output
    #check to see if we are to append the features to an existing fc
	if append == 'true':
		arcpy.AddMessage('Appending features to ' + appendFC)
		arcpy.Append_management(xInterPts, appendFC)
		outLayer = appendFC
	else:
		#or copy the final fc from the scratch gdb to the output directory/gdb
		arcpy.AddMessage('Writing ' + outFC)
		srcInterLines = os.path.join(scratchDir, xInterPts)
		arcpy.CopyFeatures_management(srcInterLines, outFC)
		outLayer = outFC

	#add the layer to the map if a data frame was chosen
	if not dfName == '':
		mxd = arcpy.mapping.MapDocument('Current')
		df = arcpy.mapping.ListDataFrames(mxd, dfName)[0]
		mxd.activeView = df
		arcpy.SetParameterAsText(10, outLayer)

except:
	tb = sys.exc_info()[2]
	tbinfo = traceback.format_tb(tb)[0]
	pymsg = tbinfo + '\n' + str(sys.exc_type)+ ': ' + str(sys.exc_value)
	arcpy.AddError(pymsg)
	raise SystemError