import arcgisscripting, fileinput, string, sys#,  win32com

gp = arcgisscripting.create()

#gp = win32com.client.Dispatch("esriGeoprocessing.GpDispatch.1")
gp.overwriteoutput = 1
gp.workspace = "D:/Workspace/PythonProjects/CrossSectionToolbox/scratch/polytest.mdb"
gp.OutputZFlag = "enabled"
gp.OutputMFlag = "disabled"
gp.xyresolution = "0.00000001"
gp.xytolerance = "0.00000001"
gp.clustertolerance = "0.0000001"

gp.createfeatureclass(gp.workspace, "polytest", "polygon", "", "", "enabled")

infile = "D:/Workspace/PythonProjects/CrossSectionToolbox/scratch/complexpolypts.csv"

cur = gp.insertcursor("polytest")
pnt = gp.createobject("point")
partarray = gp.createobject("array")
pntarray = gp.createobject("array")

try:   
    for line in fileinput.input(infile):
        pnt.x, pnt.y, pnt.z = string.split(line, ",")
        #print pnt.x, pnt.y, pnt.z
        pntarray.add(pnt)

    partarray.add(pntarray)
    feat = cur.newrow()
    #feat.SetValue("shape", partarray)
    print 1
    feat.shape = partarray
    print 2
    cur.insertrow(feat)
    fileinput.close()
    if gp.getcount_management("D:/Workspace/PythonProjects/CrossSectionToolbox/scratch/polytest") == 1:
        cur = gp.searchcursor("D:/Workspace/PythonProjects/CrossSectionToolbox/scratch/polytest")
        row = cur.next()
        print row.shape.partcount, "parts"

    del cur
    print "done"
except:
    fileinput.close()
    del cur

    