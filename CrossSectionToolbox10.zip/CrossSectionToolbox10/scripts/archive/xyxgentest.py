import arcgisscripting
from shutil import copy

gp = arcgisscripting.create()
gp.workspace = r"D:\Workspace\PythonProjects\CrossSectionToolbox\scratch"
gp.overwriteoutput = 1

def XYZGenerate(layer):
    #try:
    # open a search cursor on the events layer
    evlyr = layer + "_ev.shp"
    rows = gp.SearchCursor(evlyr, "", "", "", "MLyrFID")
    row = rows.next()
    # get the proto-layer shape type
    # as long as the shape is not point or multipoint,
    # write the geometry to a text file
    shape = row.getvalue("OrigShape")
    if shape == "polyline":
        # open a text file
        xyz = gp.workspace + "\\" + layer + "_xyz.txt"
        outf = open(xyz, "w")

        # create a point object
        pnt = gp.createobject("point")
        
        # initialize a variable to keep track of feature IDs
        ID = 0
        outf.write("0\n")
        #print ID
        # enter row loop
        while row:
            # create the geometry object
            feat = row.shape
            pnt = feat.getpart()
            x = row.getvalue("origid")
            if x == ID:
                #print pnt.x, pnt.y, row.getvalue("MapViewZ")
                outf.write(str(pnt.x) + " " + str(pnt.y) + " " + str(row.getvalue("MapViewZ")) + "\n")
            else:
                #print "END"
                #print row.getvalue("OrigID")
                #print pnt.x, pnt.y, row.getvalue("MapViewz")
                outf.write("END\n")
                outf.write(str(row.getvalue("origid")) + "\n")
                outf.write(str(pnt.x) + " " + str(pnt.y) + " " + str(row.getvalue("MapViewZ")) + "\n")
                ID = ID + 1
            row = rows.next()

        # need one last END at the end of the file
        #print "END"
        outf.write("END\n")
        outf.write("END")
        outf.close()
        
    # if proto-shape is polygon we need to write the first vertex twice, at the beginning and end of the feature
    elif shape.lower() == "polygon":
        # open a text file
        xyz = gp.workspace + "\\" + layer + "_xyz.txt"
        outf = open(xyz, "w")

        # create a point object
        pnt = gp.createobject("point")
        
        # initialize a variable to keep track of feature IDs
        ID = 0
        outf.write("0\n")
        #print ID
        # enter row loop
        #feat = row.shape
        #pnt = feat.getpart()
        #firstvtx = str(pnt.x) + " " + str(pnt.y) + " " + str(row.getvalue("MapViewZ")) + "\n"
        while row:
            # create the geometry object
            feat = row.shape
            pnt = feat.getpart()
            x = row.getvalue("origid")
            if x == ID:
                #print pnt.x, pnt.y, row.getvalue("MapViewZ")
                outf.write(str(pnt.x) + " " + str(pnt.y) + " " + str(row.getvalue("MapViewZ")) + "\n")
            else:
                #print "END"
                #print row.getvalue("OrigID")
                #print pnt.x, pnt.y, row.getvalue("MapViewz")
                # first print the coordinates of the first vertex in the polygon to close it
                #outf.write(firstvtx)
                outf.write("END\n")
                outf.write(str(row.getvalue("origid")) + "\n")
                outf.write(str(pnt.x) + " " + str(pnt.y) + " " + str(row.getvalue("MapViewZ")) + "\n")
                # reset the firstvtx variable
                firstvtx = str(pnt.x) + " " + str(pnt.y) + " " + str(row.getvalue("MapViewZ")) + "\n"
                ID = ID + 1
            row = rows.next()

        # need one last END at the end of the file
        #print "END"
        outf.write("END\n")
        outf.write("END")
        outf.close()


##        return "success"
##    except:
####        gp.AddMessage("Problem exporting %s_ev to XYZ Generate text file..." % layer)
####        gp.AddMessage(gp.getmessages())
##        return "fail"
gp.checkoutextension("3D")
gp.toolbox = "3D"
print XYZGenerate("bw_geologycontacts")
gp.Ascii3DToFeatureClass_3D("BW_GeologyContacts_xyz.txt", "GENERATE", "contacts_3d.shp", "POLYLINE")
#copy(gp.workspace + "\\BW_GeologyContacts.dbf", gp.workspace + "\\contacts_3d.dbf")

#gp.ascii3dtofeatureclass("BWpolygons_xyz.txt", "generate", "polygons_3d.shp", "polygon")