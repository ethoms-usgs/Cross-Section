'''
Name: borehole.py
Description: ArcToolbox tool script to plot borehole stick logs
   in a cross-sectional view.
   python version of the borehole part of my
   CrossSection.dll written in VB to access ArcObjects
Requirements: python, 3D Analyst extension 
Author: Evan Thoms, U.S. Geological Survey, ethoms@usgs.gov
Date: 7/23/07
Edits beginning on 5/25/10
Upgraded to ArcGIS 10 on 7/7/11

'''

# Import modules
import os
import sys
import math
import traceback
import arcpy
import xsec_defs

# FUNCTIONS
# ***************************************************************
def checkExtensions():
    #Check for the 3d Analyst extension
    try:
        if arcpy.CheckExtension('3D') == 'Available':
            arcpy.CheckOutExtension('3D')
        else:
            raise 'LicenseError'

    except 'LicenseError':
        arcpy.AddMessage('3D Analyst extension is unavailable')
        raise SystemError
    except:
        print arcpy.GetMessages(2)

arcpy.env.overwriteOutput = True

# PARAMETERS
# ***************************************************************
# Cross-section layer
#can be a measured route, in which case the coordinate prioritiy and dem
#parameters aren't important
lineLayer = arcpy.GetParameterAsText(0)

#might be a path, so we have to get the name of the file
if os.path.isabs(lineLayer):
    lineLayer = os.path.splitext(os.path.basename(lineLayer))[0]

#can't figure out how to put this in the validator class ??
result = arcpy.GetCount_management(lineLayer)
if int(result.getOutput(0)) > 1:
    arcpy.AddError(lineLayer + ' has more than one line in it.')

# elevation raster layer
dem = arcpy.GetParameterAsText(1)

#coordinate priority - corner from which the measuring will begin
cp = xsec_defs.getCPValue(arcpy.GetParameterAsText(2))

# borehole locations points layer
bhLayer = arcpy.GetParameterAsText(3)

# borehole id field
bhIdField = arcpy.GetParameterAsText(4)

# collar Z field
bhZField = arcpy.GetParameterAsText(5)

# depth field
bhDepthField = arcpy.GetParameterAsText(6)

# intervals table
intervalsTable = arcpy.GetParameterAsText(7)

# borehole id field in interval table
intBhIdFld = arcpy.GetParameterAsText(8)

# interval top depth - depth in relation to the top of the borehole, not elevation
# if left blank will interpolate elevation from DEM
intTopDepthFld = arcpy.GetParameterAsText(9)

# interval bottom depth
intBotDepthFld = arcpy.GetParameterAsText(10)

# buffer distance
buff = arcpy.GetParameterAsText(11)

# vertical exaggeration
ve = arcpy.GetParameterAsText(12)

# output feature class
outFC = arcpy.GetParameterAsText(13)
outName = os.path.splitext(os.path.basename(outFC))[0]

#append features boolean
append = arcpy.GetParameterAsText(14)

#append to feature class...
appendFC = arcpy.GetParameterAsText(15)

if append == 'true':
	outName = os.path.splitext(os.path.basename(appendFC))[0]
	
#data frame name
dfName = arcpy.GetParameterAsText(16)


# BEGIN
# ***************************************************************
try:
	#check for 3DAnalyst extension
	checkExtensions()

	#get the scratch directory
	scratchDir = arcpy.env.scratchWorkspace

    #set the current workspace env
	arcpy.env.workspace = scratchDir
	
    #find out if lineLayer is measured and interpolated
    #(has M and Z values) - if so, we can avoid the next two function calls
	desc = arcpy.Describe(lineLayer)
	hasM = desc.hasM
	hasZ = desc.hasZ

	#add an ORIG_FID field to the table that consists of values from the OID
	desc = arcpy.Describe(lineLayer)
	idField = desc.OIDFieldName
	xsec_defs.addAndCalc(lineLayer, 'ORIG_FID', '[' + idField + ']')

    #check for Z and M values. User's responsibility to make sure the
	#units are consistent with other layers, output, etc.
	if hasZ and hasM:
		ZMline = lineLayer
	else:
        #interpolate the line to add z values
		Zline = lineLayer + '_Z'
		xsec_defs.interpolate(lineLayer, dem, Zline)
        
        #measure it and turn it into a route
		ZMline = lineLayer + '_ZM'
		xsec_defs.measureLines(Zline, 'ORIG_FID', ZMline, 'LENGTH', '#', '#', cp)

	# select the borehole location points based on the buffer distance
	arcpy.AddMessage('Selecting boreholes within ' + buff  + ' of cross section')
	arcpy.SelectLayerByLocation_management(bhLayer, 'WITHIN_A_DISTANCE', ZMline, buff)

	#figure out where the collar elevation is coming from, a user specified field or to be 
	#calculated by interpolation from the DEM and stored in 'SHAPE_Z'
	if not bhZField =='':
		ZField = bhZField
		Zboreholes = bhLayer
	else:
		#interpolate Z values for the boreholes
		Zboreholes = outName + '_Zboreholes'
		xsec_defs.interpolate(bhLayer, dem, Zboreholes)

		#add DEM Z values to Zboreholes attribute table
		xsec_defs.addZ(Zboreholes)
		
		#'SHAPE_Z' becomes the collar elevation field
		ZField = 'SHAPE_Z'

	# locate boreholes points along the cross section
	eventTable = outName + '_bhEvents'
	rProps = 'rkey POINT RouteM'
	xsec_defs.createEventTable(Zboreholes, ZMline, 'ORIG_FID', buff, eventTable, rProps)

	# make the borehole lines to be used as routes
	bhLines = outName + '_bhLines'
	xsec_defs.boreholeLines(scratchDir, bhLines, Zboreholes, eventTable, bhIdField, ZField, bhDepthField, ve)

	#if no intervals table was provided, stop here and deliver the Zboreholes as 
	#the final feature class
	if intervalsTable == '':
		if append == 'true':
			arcpy.AddMessage('Appending features to ' + appendFC)
			#schemas do not have to match but no attributes will be copied over
			#unless the fields are in both layers.
			arcpy.Append_management(bhLines, appendFC, 'NO_TEST')
			outLayer = appendFC
		else:
			#copy the final fc from the scratch gdb to the output directory/gdb
			srcLogs = os.path.join(scratchDir, bhLines)
			arcpy.CopyFeatures_management(srcLogs, outFC)
			outLayer = outFC			
	else:
		#or continue and place the intervals as events along the borehole routes
		
		#convert to routes
		bhRoutes = outName + '_bhRoutes'
		xsec_defs.measureLines(bhLines, bhIdField, bhRoutes, 'ONE_FIELD', bhDepthField, '#', 'UPPER_LEFT')

		#place borehole intervals (line events) on borehole routes
		bhIntervals = outName + '_intervals'
		xsec_defs.placeEvents(bhRoutes, bhIdField, intervalsTable, intBhIdFld, intTopDepthFld, intBotDepthFld, bhIntervals)

		#copy the final fc from the scratch gdb to the output directory/gdb
		srcIntervals = os.path.join(scratchDir, bhIntervals)
		arcpy.CopyFeatures_management(srcIntervals, outFC)
		outLayer = outFC
		
	arcpy.SelectLayerByAttribute_management(bhLayer, "CLEAR_SELECTION")
	
	#now, check for whether the user wants the output in a particular data frame
    #seems to inconsistently activate the data frame
    #layer will not be added unless Geoprocessing > Geoprocessing Options >
    #   'Add results of geoprocessing operations to the display' is checked
	if not dfName == '' and not dfName == 'ArcMap only':
		mxd = arcpy.mapping.MapDocument('Current')
		df = arcpy.mapping.ListDataFrames(mxd, dfName)[0]
		mxd.activeView = df
		arcpy.SetParameterAsText(17, outLayer)

except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = tbinfo + '\n' + str(sys.exc_type)+ ': ' + str(sys.exc_value)
    arcpy.AddError(pymsg)
    raise SystemError

#raise SystemError