'''
Name: points2XsecView.py
Description: ArcToolbox tool script to plot map-view points in a cross-sectional view

Requirements: python, 3D Analyst extension 
Author: Evan Thoms, U.S. Geological Survey, ethoms@usgs.gov
Date: 7/23/07
Edits beginning on 5/25/10

'''

# Import modules
import os
import sys
import math
import traceback
import arcpy
import xsec_defs

# FUNCTIONS
# ***************************************************************
def checkExtensions():
    #Check for the 3d Analyst extension
    try:
        gp.AddMessage('Checking out 3D Analyst extension')
        if gp.CheckExtension('3D') == 'Available':
            gp.CheckOutExtension('3D')
        else:
            raise 'LicenseError'
            
    except 'LicenseError':
        gp.AddMessage('3D Analyst extension is unavailable')
        raise SystemError
            
    except:
        # get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        pymsg = tbinfo + '\n' + str(sys.exc_type)+ ': ' + str(sys.exc_value)
        gp.AddError(pymsg)

def checkInputs(linelayer, pointlayer, ZField):
    #check the geometries and data types of the inputs
    try:
        gp.AddMessage('Checking inputs')
        
        # check that input layers are appropriate geometry
        if not (gp.describe(linelayer).ShapeType == 'Polyline'):
            gp.AddError('The line layer input is not a polyline layer.')
            raise 'endIt'
            
        result = gp.GetCount_management(linelayer)
        if  int(result.GetOutput(0)) > 1:
            gp.AddError('The line layer has more than one line.')
            raise 'endIt'
            
        if not (gp.describe(pointlayer).ShapeType == 'Point'):
            gp.AddError('Points layer input is not a point layer.')
            raise 'endIt'
                    
        if not (gp.describe(pointlayer).HasZ):
            if ZField == '':
                gp.AddError('Must specify a point elevation field when the layer is not Z aware.')
                raise 'endIt'
        ## else:
            ## if not (gp.describe(raster).DatasetType == 'RasterDataset'):
                ## gp.AddError('DEM input is not a raster layer!')
                ## raise 'endIt'
                
    except 'endIt':
        raise SystemError
    
    except:
        # get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        pymsg = tbinfo + '\n' + str(sys.exc_type)+ ': ' + str(sys.exc_value)
        gp.AddError(pymsg)



# PARAMETERS
# ***************************************************************
# Cross-section layer
lineLayer = gp.GetParameterAsText(0)

# Cross section name field
nameField = gp.GetParameterAsText(1)

#coordinate priority - corner from which the measuring will begin
cp = gp.GetParameterAsText(2)

# structural data points layer
ptLayer = gp.GetParameterAsText(3)

# collar Z field
ptZField = gp.GetParameterAsText(4)

# vertical exaggeration
ve = gp.GetParameterAsText(5)

# output directory
outDir = gp.GetParameterAsText(6)

# files prefix
outName = gp.GetParameterAsText(7)

# keep intermediate files?
keepf = gp.GetParameterAsText(8)

# BEGIN
# ***************************************************************
# check inputs
checkInputs(lineLayer, ptLayer, ptZField)

#check for 3DAnalyst extension
#checkExtensions()

#get the path to the scratch geodatabase
scriptsdir = os.path.dirname(sys.argv[0])
tbxdir = os.path.dirname(scriptsdir)
scratchDir = os.path.join(tbxdir, 'scratch', 'scratch.gdb')

#set default workspace to the scratch gdb
gp.workspace = scratchDir

#copy the line feature class to the scratch gdb so that we get a LENGTH field
#in the units of the coordinate system
lineCopy = lineLayer + '_copy'
gp.AddMessage('Copying ' + lineLayer + ' to ' + scratchDir)    
gp.MakeFeatureLayer(lineLayer, 'layer')
gp.CopyFeatures_management('layer', lineCopy)

#measure it and turn it into a route
ZMline = lineLayer + '_ZM'
xsec_defs.measureLines(gp, lineCopy, nameField, ZMline, 'LENGTH', '#', '#', cp, scratchDir)

# figure out where the Z value is coming from, the SHAPE _Z field or a 
# user specified field
if not ptZField =='':
    ZField = ptZField
else:
    # Add SHAPE Z values to ptLayer attribute table
    xsec_defs.addZ(gp, ptLayer)
    ZField = 'SHAPE_Z'     

# locate the points along the newly created route
eventTable = outName + '_ptEvents'
rProps = 'rkey POINT RouteM'
xsec_defs.createEventTable(gp, ptLayer, ZMline, nameField, '1000', eventTable, rProps)

# make the new features
flippedPts = outName + '_Flip'
xsec_defs.zPoints2XSec(gp, flippedPts, ptLayer, eventTable, ZField, ve, scratchDir)

finalPts = os.path.join(scratchDir, flippedPts)
gp.workspace = outDir
    
#copyfeatures method below doesn't work for some reason on the permanent
#feature class. Need to make a temporary layer ??
gp.AddMessage('Copying ' + finalPts + ' to ' + outDir)    
gp.MakeFeatureLayer(finalPts, 'layer')
gp.CopyFeatures_management('layer', outName)
    
#add the results to the map
gp.SetParameterAsText(9, outName)

# cleanup
xsec_defs.cleanup(gp, keepf, scratchDir)
